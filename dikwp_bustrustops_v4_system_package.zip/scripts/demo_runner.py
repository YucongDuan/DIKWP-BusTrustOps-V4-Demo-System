import json, pathlib, argparse
root = pathlib.Path(__file__).resolve().parents[1]
scenarios = json.loads((root/'data'/'scenarios.json').read_text(encoding='utf-8'))
parser = argparse.ArgumentParser()
parser.add_argument('--scenario', default='autonomous', choices=list(scenarios))
args = parser.parse_args()
s = scenarios[args.scenario]
print('SCENARIO:', s['title'])
print('RISK:', s['risk'])
print('CLOSURE:', s['closure'])
print('\nDIKWP:')
for k,v in s['dikwp'].items(): print(f'{k}: {v}')
print('\nACTION TICKET:')
for k,v in s['ticket'].items(): print(f'{k}: {v}')
