# 15-Minute Demo Script

1. Minute 0-2: Explain why true production data is not required for first meeting.
2. Minute 2-5: Open overview and show four data modes.
3. Minute 5-8: Run autonomous group anomaly scenario.
4. Minute 8-10: Show Evidence Ledger and DIKWP closure.
5. Minute 10-12: Show Action Ticket and role governance.
6. Minute 12-14: Show Scorecard and export JSON.
7. Minute 14-15: Close with 30-day pilot path.
