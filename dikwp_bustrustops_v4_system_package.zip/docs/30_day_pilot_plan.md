# 30-Day Pilot Plan

Week 1: confirm boundaries, roles, data mode, and synthetic demo.
Week 2: collect 30-50 desensitized SOP/case materials.
Week 3: generate Evidence Ledger, DIKWP cards, Action Tickets and microcases.
Week 4: review with business roles, produce management report and next-phase SOW.

Deliverables:
- demo console
- evidence ledger
- 30+ action ticket samples
- 4 scenario replay reports
- white-box evaluation report
- next-phase SOW
