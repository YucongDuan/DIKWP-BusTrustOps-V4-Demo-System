# System Architecture

DIKWP BusTrustOps V4 is organized into eight offline layers:
1. Case input layer: synthetic, desensitized SOP/case, CSV/Excel replay, read-only sandbox.
2. Evidence Ledger layer: all sources are registered before generation.
3. DIKWP Knowledge Card layer: D/I/K/W/P/R cards.
4. SemanticClosure Engine: anchors, noise, residuals, stability.
5. Answer Card generator: draft only.
6. Action Ticket generator: owner, kill, recovery, control level.
7. Role Governance layer: permissions and denial boundaries.
8. White-box Scorecard layer: metrics, audit, transferability.
