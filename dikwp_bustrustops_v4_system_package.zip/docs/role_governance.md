# Role Governance

Leadership sees value, risks and summary metrics.
Operations can review service or dispatch-related tickets.
Safety owns C5 safety escalation.
Customer service owns answer cards and external draft review.
New-energy operations review SOC/charger conflicts.
IT owns data mode, anonymization and audit log.
DIKWP expert reviews semantic closure and white-box score.
Regulator observer views emergency push packs and timeline.
