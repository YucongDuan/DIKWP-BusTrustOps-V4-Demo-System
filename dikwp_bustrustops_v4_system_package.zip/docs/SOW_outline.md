# Statement of Work Outline

## Scope
Offline DIKWP semantic governance demo for bus enterprise scenarios.

## Inputs
Synthetic data, desensitized SOPs, service complaints, safety cases, SOC/charging examples.

## Outputs
Evidence Ledger, Answer Cards, Action Tickets, role governance matrix, white-box scorecard, demo report.

## Exclusions
No production dispatch. No vehicle control. No charger control. No ticketing or camera integration. No automatic public release.
