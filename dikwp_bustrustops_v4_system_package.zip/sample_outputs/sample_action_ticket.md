# Sample Action Ticket

Ticket: T-AD-20260611-012
Control level: C5 / rehearsal
Owner: emergency command + government linkage interface + supplier technical interface
Proposal: regional limiting, 1-minute push pack, rescue grid priority, passenger protection script.
Kill: do not send to production vehicle or government platform without formal authorization.
Recovery: after rehearsal, generate audit replay and improvement list.
